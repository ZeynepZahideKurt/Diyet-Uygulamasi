﻿using Diet_BL.Services;
using Diet_Model.Entity;
using Diet_Model.Enum;
using NodaTime;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Diyet
{
    public partial class frmComparisonReport : Form
    {
        CategoryServices categoryService;
        MainTableServices mainTableService;
        UserService userService;
        public frmComparisonReport()
        {
            InitializeComponent();
            categoryService=new CategoryServices();
            mainTableService = new MainTableServices();
            userService=new UserService();

        }
        IEnumerable<LocalDate> GetWeekly(int year, int month, int week)
        {
            LocalDate date = new LocalDate(year, month, 1).PlusDays(-1);
            for (int i = 0; i < week; i++)
            {
                date = date.Previous(IsoDayOfWeek.Sunday);
            }
            // bir hafta yedi gün
            for (int i = 0; i < 7; i++)
            {
                yield return date;
                date = date.PlusDays(1);
            }
        }
        //<LocalDate<List>> GetMonthly(int year, int month, int week)
        //{
        //    LocalDate date = new LocalDate(year, month, 1).PlusDays(-1);
        //    for (int i = 0; i < week; i++)
        //    {
        //        date = date.Previous(IsoDayOfWeek.Sunday);
        //    }
        //    // bir ay ortalama otuz gün
        //    for (int i = 0; i < month; i++)
        //    {
        //        yield return date;
        //        date = date.PlusDays(1);
        //    }
             

        //}
        private void FillCmbCategory()
        {
            cmbTypeFood.DataSource = categoryService.GetList();
            cmbTypeFood.DisplayMember = "CategoryName";
            cmbTypeFood.ValueMember = "ID";
        }
        private void FillCmbMeal()
        {
            string[] mealname = Enum.GetNames(typeof(MealName));
            cmbMeals.DataSource = mealname;

        }
        private void frmComparisonReport_Load(object sender, EventArgs e)
        {
            FillCmbMeal();
            FillCmbCategory();

        }
        private bool GetPeriodType()
        {
            if (radioButton1.Checked)
            {
                return true;
                
            }
            else
            {
                return false;
            }
        }

        private void gradientPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void rprOlustur_Click(object sender, EventArgs e)
        {
            var meals = cmbMeals.SelectedIndex;
            var food = cmbTypeFood.SelectedIndex;
            var tarih = DateTime.Now;
            if (radioButton1.Checked == true)
            {
                var startDate = tarih.AddDays(-30).ToString();
                var endDate = tarih.ToString();
                chart1.DataSource = mainTableService.GetRaport(meals, food, startDate,endDate,);
                chart1.Series["Günlük Kalori"].XValueMember = "Kullanıcılar";
                chart1.Series["Günlük Kalori"].YValueMembers = "Besin Tüketimi";
                chart1.DataBind();
            }
            else
            {
                var startDate = tarih.AddDays(-7).ToString();
                var endDate = tarih.ToString();
                chart1.DataSource = mainTableService.GetRaport(meals, food, startDate, endDate, chart1   );
                chart1.Series["Günlük Kalori"].XValueMember = "Kullanıcılar";
                chart1.Series["Günlük Kalori"].YValueMembers = "Besin Tüketimi";
                chart1.DataBind();
                //chart1.Titles.Add(dateTimePicker1.Value.ToString() + " - " + dateTimePicker2.Value.ToString() + " Arasında Alınan Kalori Değeri");
            }



        }

        private void cmbTypeFood_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }
    }
}

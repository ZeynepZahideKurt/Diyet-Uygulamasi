﻿using Diet_Model.Entity;
using Diet_Model.Enum;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

namespace Diet_DAL.Repositories
{
    public class MainTableRepository
    {
        AppDbContext dbContext;
        public MainTableRepository()
        {
            dbContext = new AppDbContext();
        }
        public bool Insert(MainTable mainTable)
        {
            dbContext.MainTables.Add(mainTable);
            return dbContext.SaveChanges() > 0;
        }

        public List<MainTable> GetListMainTablesByID(int mainTableid)
        {
            return dbContext.MainTables.Where(a => a.ID == mainTableid).ToList();
        }

        public List<MainTable> GetAllMainTables()
        {
            return dbContext.MainTables.OrderBy(a => a.ID).ToList();
        }

        public MainTable GetMainTableById(int mainTableId)
        {
            return dbContext.MainTables.Where(a => a.ID == mainTableId).FirstOrDefault();
        }

        public List<MainTable> GetListMainTablesByUserID(int userID)
        {
            return dbContext.MainTables.Where(a => a.UserID==userID).ToList();
        }

        public List<MainTable> GetListMainTablesByMealID(int mealID)
        {
            return dbContext.MainTables.Where(a => a.MealID== mealID).ToList();
        }

        public List<MainTable> GetListMainTablesByNutrientID(int nutrientID)
        {
            return dbContext.MainTables.Where(a => a.NutrientID == nutrientID).ToList();
        }

        public MainTable GetMainTablesByUserID(int userID)
        {
            return dbContext.MainTables.Where(a => a.UserID == userID).FirstOrDefault();
        }

        public MainTable GetMainTablesByMealID(int mealID)
        {
            return dbContext.MainTables.Where(a => a.MealID == mealID).FirstOrDefault();
        }

        public MainTable GetMainTablesByNutrientID(int nutrientID)
        {
            return dbContext.MainTables.Where(a => a.NutrientID == nutrientID).FirstOrDefault();
        }

        public List<ComparisonRapor>  GetCategorybyUserID( int categoryId, MealName mealName,DateTime baslTrh, DateTime bitisTrh,Chart c1)
        {
            //select u.ID,COUNT(c.ID) from Users as u
            //                        join MainTables as m on u.ID = m.UserID
            //                        join Meals as meal on m.MealID = meal.ID
            //                        join Nutrients as n on n.ID = m.NutrientID
            //                        join Categories as c on c.ID = n.CategoryID
            //                        where c.ID = 1 and meal.MealName = 0 and meal.CreateTime BETWEEN '2023-03-22 00:52:49.283' and '2023-03-22 01:11:04.863'
            //                        group by u.ID;


            //var adminrapor = (from u in dbContext.Users
            //                  join m in dbContext.MainTables on u.ID equals m.UserID
            //                  join meal in dbContext.Meals on m.MealID equals meal.ID
            //                  join n in dbContext.Nutrients on n.ID equals m.NutrientID
            //                  join c in dbContext.Categories on c.ID = n.CategoryID
            //                  where c.ID = categoryId && meal.MealName = mealId && (meal.CreateTime >= baslTrh && meal.CreateTime <= bitisTrh)
            //                  group u by u.ID into g
            //                  select new
            //                  {
            //                      UserId = g.Key.ToString(),
            //                      CategoryAdet = dbContext.Categories.Count(c => c.ID),

            //                  }).ToList();
 

            var comparisonRapor = (from u in dbContext.Users
                              join mt in dbContext.MainTables on u.ID equals mt.UserID
                              join m in dbContext.Meals on mt.MealID equals m.ID
                              join n in dbContext.Nutrients on mt.NutrientID equals n.ID
                              join c in dbContext.Categories on n.CategoryID equals c.ID
                              where c.ID == categoryId && m.MealName == mealName && (m.CreateTime>= baslTrh && m.CreateTime <= bitisTrh)
                              group u by u.ID into g
                              select new
                              {
                                  UserId = g.Key.ToString(),
                                  CategoryAdet = dbContext.Categories.Count(),

                              }).ToList();
             c1.

        }
    }
    public class ComparisonRapor
    {
        public int UserId { get; set; }
        public int CategoryAdet { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diet_Model.Enum
{
    public enum Amount
    {

        Gram, Milliliter, Piece, Bowl, Tablespoon, Slice


    }
}

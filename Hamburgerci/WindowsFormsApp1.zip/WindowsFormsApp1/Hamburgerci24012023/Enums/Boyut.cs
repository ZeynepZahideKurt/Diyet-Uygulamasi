﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hamburgerci24012023.Enums
{
    public enum Boyut
    {
        Kucuk,Orta,Buyuk
    }
}

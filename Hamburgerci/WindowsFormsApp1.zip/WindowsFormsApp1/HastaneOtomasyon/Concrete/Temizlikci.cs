﻿using HastaneOtomasyon.Abstract;
using HastaneOtomasyon.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HastaneOtomasyon.Concrete
{
    internal class Temizlikci : Personel, ISil
    {
        public void CamSil()
        {
            //
        }

        public void TemilzikYap()
        {
           //
        }
    }
}

﻿using HastaneOtomasyon.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HastaneOtomasyon.Interfaces
{
    internal interface IAlan
    {
        Alan Alan { get; }
    }
}

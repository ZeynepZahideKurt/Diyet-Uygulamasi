﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HastaneOtomasyon.Enums
{
    public enum Alan
    {
        Dahiliye,
        GenelCerrahi,
        Acil,
        KBB,       
        Psikiyatri,
        Goz,
        Dogum
    }
    public enum Bina
    {
        ABlok,BBlok,CBlok
    }
    public enum Cinsiyet
    {
        Erkek,Kadin
    }
}
